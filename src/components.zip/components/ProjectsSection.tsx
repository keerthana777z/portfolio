import { motion } from "framer-motion";
import { Github } from "lucide-react";
import { Button } from "@/components/ui/button";

const projects = [
  {
    title: "Sentiment Analysis Engine",
    description: "Built a comprehensive NLP pipeline for analyzing customer sentiment from social media data. The system processes large volumes of text data, classifies sentiment with 94% accuracy, and provides actionable insights through an interactive dashboard.",
    tech: ["Python", "NLTK", "TensorFlow", "Flask", "MongoDB"],
    github: "#",
  },
  {
    title: "Stock Price Predictor",
    description: "Developed an LSTM-based deep learning model to predict stock prices using historical data and technical indicators. Implemented feature engineering techniques and achieved a 15% improvement in prediction accuracy over baseline models.",
    tech: ["Python", "Keras", "Pandas", "Scikit-learn", "Streamlit"],
    github: "#",
  },
  {
    title: "Image Classification System",
    description: "Created a CNN-based image classification system capable of identifying objects across 100 categories. Utilized transfer learning with ResNet50 architecture and deployed the model as a REST API for real-time predictions.",
    tech: ["PyTorch", "OpenCV", "FastAPI", "Docker", "AWS"],
    github: "#",
  },
  {
    title: "Recommendation Engine",
    description: "Designed a hybrid recommendation system combining collaborative filtering and content-based approaches. The system analyzes user behavior patterns and item features to provide personalized recommendations with high engagement rates.",
    tech: ["Python", "Surprise", "TensorFlow", "Redis", "PostgreSQL"],
    github: "#",
  },
];

const ProjectCard = ({ project, index }: { project: typeof projects[0]; index: number }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="project-card"
    >
      <div className="flex flex-col h-full">
        <h3 className="text-xl font-heading font-semibold text-foreground mb-4 group-hover:text-primary transition-colors">
          {project.title}
        </h3>

        <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-grow">
          {project.description}
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          {project.tech.map((tech) => (
            <span
              key={tech}
              className="text-xs px-3 py-1 rounded-full bg-secondary text-muted-foreground border border-border"
            >
              {tech}
            </span>
          ))}
        </div>

        <Button
          variant="outline"
          size="sm"
          className="w-fit border-primary/30 hover:bg-primary/10 hover:border-primary/50"
          asChild
        >
          <a href={project.github} target="_blank" rel="noopener noreferrer">
            <Github className="w-4 h-4 mr-2" />
            GitHub
          </a>
        </Button>
      </div>
    </motion.div>
  );
};

const ProjectsSection = () => {
  return (
    <section id="projects" className="py-24 md:py-32 relative z-10">
      <div className="container px-6 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="section-title text-foreground mb-4">Featured Projects</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A selection of projects showcasing my skills in AI, ML, and Data Science.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {projects.map((project, index) => (
            <ProjectCard key={project.title} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
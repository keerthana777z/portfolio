import { motion } from "framer-motion";
import { Plane, Mountain, Trophy, Swords, Crown, BookOpen } from "lucide-react";

const hobbies = [
  { label: "Traveling", icon: Plane },
  { label: "Hiking", icon: Mountain },
  { label: "Sports", icon: Trophy },
  { label: "Taekwondo", icon: Swords },
  { label: "Chess", icon: Crown },
  { label: "Reading Books", icon: BookOpen },
];

const HobbiesSection = () => {
  return (
    <section id="hobbies" className="py-24 md:py-32 relative z-10">
      <div className="container px-6 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="section-title text-foreground mb-4">Beyond the Code</h2>
          <p className="text-muted-foreground text-lg">
            What keeps me balanced and inspired outside of tech.
          </p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-4 max-w-3xl mx-auto">
          {hobbies.map((hobby, index) => {
            const Icon = hobby.icon;
            return (
              <motion.div
                key={hobby.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.4 }}
                className="hobby-pill cursor-default"
              >
                <Icon className="w-4 h-4 text-primary" />
                <span className="text-foreground">{hobby.label}</span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default HobbiesSection;